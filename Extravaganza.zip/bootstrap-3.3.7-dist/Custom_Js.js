﻿$(window).load(function () {
    $('.loader').fadeOut();
});