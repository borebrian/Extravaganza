﻿function devv() {
    $("#v2").modal({
        show: false,
        backdrop: 'static'

    });
    $('#v2').modal("show");
}
function addingusermodal() {
    $("#searches").modal({
        show: false,
        backdrop: 'static'

    });
    $('#searches').modal("show");
}
function phone() {
    $("#phone").modal({
        show: false,
        backdrop: 'static'

    });
    $('#phone').modal("show");
}
function voted() {
    $("#voted").modal({
        show: false,
        backdrop: 'static'

    });
    $('#voted').modal("show");
}
function voted11() {
    $("#voted1").modal({
        show: false,
        backdrop: 'static'

    });
    $('#voted1').modal("show");
}

function confirmed(x, y) {
    $("#informodal").modal({
            show: false,
            backdrop: 'static'


        });
    $('#informodal').modal("show");
    $("#inforr").html(x);
    $("#titlee").html(y);



}